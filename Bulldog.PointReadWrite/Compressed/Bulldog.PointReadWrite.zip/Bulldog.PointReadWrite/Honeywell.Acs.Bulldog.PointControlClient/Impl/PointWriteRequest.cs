﻿namespace Honeywell.Acs.Bulldog.PointControlClient.Impl
{
    class PointWriteRequest
    {
        public object Value { get; set; }
    }
}